﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP3EX3
{
    class Program
    {
        static string GetSaisieUtilisateur(string message)
        {
            Console.WriteLine(message);
            return (Console.ReadLine());
        }

        static int GetVolumeparallelepipede(int lng, int lrg, int hau)
        {
            return (int)(lng * lrg * hau);
        }
        static int GetSurfaceparallelepipede(int lng, int lrg, int hau)
        {
            return (int)(lng * lrg);
        }
        static void Main(string[] args)
        {


            int longueur, largeur,hauteur;
            Console.WriteLine("Calcul aire et périmètre d'un rectangle\n");
            longueur = int.Parse(GetSaisieUtilisateur("Saisissez la longueur du parallelepipede (m) : "));
            largeur = int.Parse(GetSaisieUtilisateur("Saisissez la largeur du parallelepipede (m) : "));
            hauteur = int.Parse(GetSaisieUtilisateur("Saisissez la hauteur du parallelepipede (m) : "));
            Console.WriteLine("\nParallelepipede de longueur {0}m  de largeur {1}m et de hauteur {2}m ", longueur, largeur,hauteur) ;
            Console.WriteLine("---------------------------------------------");
            Console.WriteLine("Volume : {0}m2", GetVolumeparallelepipede(longueur, largeur,hauteur));
            Console.WriteLine("Surface : {0}m", GetSurfaceparallelepipede(longueur, largeur, hauteur));
            Console.ReadLine();

        }
    }
}

