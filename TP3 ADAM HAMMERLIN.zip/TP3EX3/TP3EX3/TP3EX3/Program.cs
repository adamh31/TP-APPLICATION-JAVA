﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP3EX3
{
    class Program
    {
        static string GetSaisieUtilisateur(string message)
        {
            Console.WriteLine(message);
            return (Console.ReadLine());
        }

        static int GetAireRectangle(int lng, int lrg)
        {
            return (int)(lng * lrg);
        }
        static int GetPerimetreRectangle(int lng, int lrg)
        {
            return (int)(lng + lrg) * 2;
        }
        static void Main(string[] args)
        {


            int longueur, largeur;
            Console.WriteLine("Calcul aire et périmètre d'un rectangle\n");
            longueur = int.Parse(GetSaisieUtilisateur("Saisissez la longueur du rectangle (m) : "));
            largeur = int.Parse(GetSaisieUtilisateur("Saisissez la largeur du rectangle (m) : "));
            Console.WriteLine("\nRectangle de longueur {0}m et de largeur {1}m", longueur, largeur);
            Console.WriteLine("---------------------------------------------");
            Console.WriteLine("Aire : {0}m2", GetAireRectangle(longueur, largeur));
            Console.WriteLine("Périmètre : {0}m", GetPerimetreRectangle(longueur, largeur));
            Console.ReadLine();

        }
    }
}

