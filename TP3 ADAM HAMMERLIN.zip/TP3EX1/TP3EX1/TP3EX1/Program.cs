﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP3EX1
{
    class Program
    {

        static void AfficheIdentite(string nom, string prenom, int anneeNaissance)
        {
            int anneeActuelle = 2021;
            Console.WriteLine("Nom : " + nom);
            Console.WriteLine("Prenom :" + prenom);
            Console.WriteLine("Age : {0}", anneeActuelle - anneeNaissance);
            Console.Write("\n");
        }

        static void Main(string[] args)
        {
            AfficheIdentite("FRAGIONE", "Philippe", 1968);
            AfficheIdentite("COTENTIN", "Aurélien", 1982);
            AfficheIdentite("ORDONEZ", "Florian-José", 1993);
            Console.ReadKey();

        }
    }
}
