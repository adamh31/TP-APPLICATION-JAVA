﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP3EX2
{
    class Program
    {

        static void AfficheCalculs(double x, double y)
        {
            Console.Write("inverse de x :");
            Console.WriteLine(-x);

            Console.Write("inverse de y :");
            Console.WriteLine(-y);

            Console.Write("addition :");
            Console.WriteLine(x + "+" + y + "=" + (x + y));

            Console.Write("multiplication :");
            Console.WriteLine(x + "*" + y + "=" + (x * y));

            Console.Write("soustraction :");
            Console.WriteLine(x + "-" + y + "=" + (x - y));

            Console.Write("division :");
            Console.WriteLine(x + "/" + y + "=" + (x / y));

            Console.Write("modulo :");
            Console.WriteLine(x + "%" + y + "=" + (x % y));
        }

        static void Main(string[] args)
        {
            double a;
            double b;

            Console.WriteLine("Saisir la valeur de la variable x");
            a = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Saisir la valeur de la variable y");
            b = Convert.ToDouble(Console.ReadLine());
            

            AfficheCalculs(a, b);
            Console.Write("\n");
            Console.WriteLine("Saisir la valeur de la variable x");
            
            a = Convert.ToDouble(Console.ReadLine());
          
            Console.WriteLine("Saisir la valeur de la variable y");
            
            b = Convert.ToDouble(Console.ReadLine());
            AfficheCalculs(a, b);
            Console.ReadKey();




        }
    }
}
