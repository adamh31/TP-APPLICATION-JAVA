﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP5EX1
{
    class Program
    {
        static void Main(string[] args)
        {

            int choix;
            Console.WriteLine("1. Manger \n2. Dormir \n3. Travailler \n4. Chiller \n0. Quitter le programme");
            do {
                Console.WriteLine("Choix ?");
                choix = int.Parse(Console.ReadLine());

                {
                    switch (choix)
                    {
                        case 1:
                            Console.WriteLine("miam");
                            break;
                        case 2:
                            Console.WriteLine("rrrrhhh");
                            break;
                        case 3:
                            Console.WriteLine("allez");
                            break;
                        case 4:
                            Console.WriteLine("cool");
                            break;
                        case 0:
                            break;
                    }

                    }
                }
                while (choix != 0) ;


            }
  
            }
}

