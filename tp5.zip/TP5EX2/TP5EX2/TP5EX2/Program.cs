﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP5EX2
{
    class Program
    {
        static void Main(string[] args)
        {
            int i =1;
            int somme = 0;

            while (i <= 4) 
            {
                Console.WriteLine("Nouveau tour avec i");
                
                somme = somme+ i;
                i = i + 1;
                Console.WriteLine("Somme vaut maintenant "+somme); 


            } 
            Console.WriteLine("La somme des 4 premiers entiers est "+somme);
            Console.ReadKey();
        }
    }
}
