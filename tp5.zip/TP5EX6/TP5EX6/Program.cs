﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP5EX6
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] notes;
            int n =0;
            float moy=0;
            int tour = 0;
            notes = new int[n];
            Console.WriteLine("Veuillez saisir le nombre de notes");
            n = int.Parse(Console.ReadLine());
            for (int i=0; i<n; i++)
            {
                Console.WriteLine("Entrez une valeur int");
                notes[i] =int.Parse(Console.ReadLine());

            }
            foreach (int i in notes) {
                Console.WriteLine( i);
                moy = moy + i;
                tour = tour + 1;
              
            }
            moy = moy / tour;
            Console.WriteLine("La moyenne est de " + moy);

            Console.ReadKey();
        }
    }
}
