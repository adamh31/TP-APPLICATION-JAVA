/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp1ex1etapes1et2;

/**
 *
 * @author Philippe
 */
public class Perso {

    // Etape 1
    private String nom;
    private int vie;
    private int force;

    // Etape 2.1
    public Perso() {
        this.nom = "noname";
        this.vie = 100;
        this.force = 30;
        
        // Etape 2.4 : remplacer les lignes précédentes par :
        // this("noname");
    }

    // Etape 2.2
    public Perso(String nomPerso) {
        this.nom = nomPerso;
        this.vie = 100;
        this.force = 30;

        // Etape 2.4 : remplacer les lignes précédentes par :
        // this(nomPerso, 100, 30);
    }

    // Etape 2.3
    public Perso(String nomPerso, int vie, int force) {
        this.nom = nomPerso;
        this.vie = vie;
        this.force = force;
    }

    // Etape 1
    public String toString() {
        return this.nom + " - Vie : " + this.vie + " - Force : " + this.force;
    }

}
