﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP4Ex5
{
    class Program
    {
        static void Main(string[] args)
        {
            char touche;
            Console.WriteLine("Taper sur une touche:");
            touche = Console.ReadKey().KeyChar;
            if ((touche >= 'a') && (touche <= 'z'))
            {
                Console.WriteLine("\nMinuscule");
            }
            else if ((touche >= 'A') && (touche <= 'Z'))
            {
                Console.WriteLine("\nMajuscule");
            }
            else if ((touche >= 0) && (touche >= 9))
            {
                Console.WriteLine("\nChiffres");
            }
            Console.ReadKey();
        }
    }
}
