﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP4EX9
{
    class Program
    {
        static void Main(string[] args)
        {
            
  string operation;

            int operateur;

            Console.WriteLine("Entrez une opération simple avec des valeurs entre 0 et 9 !");

            operation = Console.ReadLine();

            operateur = operation[1];

        
            switch(operateur) 
            {
                case 42:
                    Console.WriteLine("{0} {1} {2} = {3}",operation[0], operation[1], operation[2],Char.GetNumericValue(operation[0])* Char.GetNumericValue(operation[2]));
                  break;
                case 43:
                    Console.WriteLine(" {0} {1} {2} = {3}",operation[0], operation[1], operation[2],Char.GetNumericValue(operation[0])+ Char.GetNumericValue(operation[2]));
                  break;
                case 45:
                    Console.WriteLine(" {0} {1} {2} = {3}", operation[0], operation[1], operation[2], Char.GetNumericValue(operation[0])- Char.GetNumericValue(operation[2]));
                  break;
                case 47:
                    Console.WriteLine("{0} {1} {2} = {3}", operation[0], operation[1], operation[2], Char.GetNumericValue(operation[0])/ Char.GetNumericValue(operation[2]));
                    break;
            }
            Console.ReadKey();


        }
    }
}
