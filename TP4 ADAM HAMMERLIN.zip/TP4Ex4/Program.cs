﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP4Ex4
{
    class Program
    {
        static void Main(string[] args)
        {
            char lettre;
            Console.WriteLine("Entrez une lettre minuscule");
            lettre = char.Parse(Console.ReadLine());
            if (lettre == 'a' || (lettre == 'e') || (lettre == 'i') || (lettre == 'o') || (lettre == 'u') || (lettre == 'y'))
            {
                Console.WriteLine("La lettre que vous avez saisie est une voyelle.");
            }
            else
            {
                Console.WriteLine("La lettre saisie que vous avez est une consonne.");
            }

            Console.ReadKey();
        }
    }
}
