﻿//adamh
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace TP4EX8
    {
        class Program
        {
            static void Main(string[] args)
            {
                int anneeNaissance, age;

                Console.WriteLine("Entrez votre année de naissance");

                anneeNaissance = int.Parse(Console.ReadLine());

                age = (anneeNaissance - 1900) % 12;

                switch (age)
                {
                    case (0):
                        Console.WriteLine("https://www.chine-nouvelle.com/astrologie/signes/rat.html");
                        break;

                    case (1):
                        Console.WriteLine("https://www.chine-nouvelle.com/astrologie/signes/boeuf.html");
                        break;

                    case (2):
                        Console.WriteLine("https://www.chine-nouvelle.com/astrologie/signes/tigre.html");
                        break;

                    case (3):
                        Console.WriteLine("https://www.chine-nouvelle.com/astrologie/signes/lapin.html");
                        break;

                    case (4):
                        Console.WriteLine("https://www.chine-nouvelle.com/astrologie/signes/dragon.html");
                        break;


                    case (5):
                        Console.WriteLine("https://www.chine-nouvelle.com/astrologie/signes/serpent.html");
                        break;

                    case (6):
                        Console.WriteLine("https://www.chine-nouvelle.com/astrologie/signes/cheval.html");
                        break;

                    case (7):
                        Console.WriteLine("https://www.chine-nouvelle.com/astrologie/signes/chevre.html");
                        break;


                    case (8):
                        Console.WriteLine("https://www.chine-nouvelle.com/astrologie/signes/singe.html");
                        break;

                    case (9):
                        Console.WriteLine("https://www.chine-nouvelle.com/astrologie/signes/coq.html");
                        break;

                    case (10):
                        Console.WriteLine("https://www.chine-nouvelle.com/astrologie/signes/chien.html");
                        break;


                    case (11):
                        Console.WriteLine("https://www.chine-nouvelle.com/astrologie/signes/cochon.html");
                        break;

                }
                Console.ReadKey();

            }
        }
    }

