﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP4Ex2
{
    class Program
    {
        static void Main(string[] args)
        {
            int temperature;
            Console.WriteLine("Entrez la température de l'eau:");
            temperature = int.Parse(Console.ReadLine());
            if (temperature <= 0)
            {
                Console.WriteLine("Glace");
            }
            else if (temperature <= 100)
            {
                Console.WriteLine("Liquide");
            }
            else if (temperature > 100)
            {
                Console.WriteLine("Vapeur");
            }

            Console.ReadKey();
        }
    }
}
