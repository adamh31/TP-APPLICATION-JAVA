﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP4Ex1
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b;
            Console.WriteLine("Saisir la valeur de a:");
            a=int.Parse(Console.ReadLine());
            Console.WriteLine("Saisissez la valeur de b:");
            b=int.Parse(Console.ReadLine());

            if (a > b)
            {
                Console.WriteLine("a est supérieur à b");
            }
            else if(a<b)
            {
                Console.WriteLine("a est inférieur à b");
            }
            else if (a == b)
            {
                Console.WriteLine("a est égal à b");
            }
            Console.ReadKey();
        }
    }
}
