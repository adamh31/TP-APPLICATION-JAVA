﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP4EX6
{
    class Program
    {
        static void Main(string[] args)
        {
            int repAge;
            char repMajeur;
            Console.Write("Quel âge avez-vous ? ");
            repAge = int.Parse(Console.ReadLine());
            Console.Write("Etes-vous majeur (o/n) ? ");
            repMajeur = char.Parse(Console.ReadLine());
            if ((repAge >= 18 && (repMajeur) == 'n') || (repAge < 18 && (repMajeur == 'o')))

                Console.WriteLine("Menteur !");
            
                
            Console.ReadKey();
            }
        }
    }

