﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP4EX7
{
    class Program

    {
        
        
            static void Main(string[] args)
            {

                int m, n;


                Console.WriteLine("Entrez m :");
                m = int.Parse(Console.ReadLine());

                Console.WriteLine("Entrez n :");
                n = int.Parse(Console.ReadLine());



                if (m % n == 0)
                {
                    Console.WriteLine("m est divisible par n");

                }
                else
                {
                    Console.WriteLine("m n'est divisible par n");

                }




                Console.ReadKey();
            }
        }
    }


    