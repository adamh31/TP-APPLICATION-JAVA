﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP4Ex3
{
    class Program
    {
        static void Main(string[] args)
        {
            int age;
            Console.WriteLine("Entrez votre âge:");
            age = int.Parse(Console.ReadLine());
            if (age >= 12)
                Console.WriteLine("Vous etes cadet");
            else if (age >= 10)
                Console.WriteLine("Vous etes minime");
            else if (age >= 8)
                Console.WriteLine("Vous etes pupille");
            else if (age >= 6)
                Console.WriteLine("Vous etes poussin");
            Console.ReadKey();
        }
    }
}


