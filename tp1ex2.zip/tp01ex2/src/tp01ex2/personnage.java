/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp01ex2;

/**
 *
 * @author a.hammerlin
 */
public class personnage {
    private String nom;
    private String prenom;
    private char genre;
    private int age;
    
    public personnage(String nom , String prenom, char genre , int age){
        this.nom=nom;
        this.prenom=prenom;
        this.genre=genre;
        this.age=age;
        }
    public String toString(){
            return nom + prenom + genre + age + "ans" ;
    }
    public int anniversaire(){
        this.age=age;
    }
}
