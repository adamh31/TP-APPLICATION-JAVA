package tp4_hammerlinadam;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author a.hammerlin
 */
abstract public class Media {

    protected String titre;
    protected int annee;

    public Media(String titre, int annee) {
        this.titre = titre;
        this.annee = annee;
    }

    public String getTitre() {
        return this.titre;
    }

    public int getAnnee() {
        return this.annee;
    }

    abstract public void lecture();

    abstract public String getInfo();

    public String toString() {
        return (this.getTitre() + " (" + this.getAnnee() + ") " + this.getInfo());
    }
}
