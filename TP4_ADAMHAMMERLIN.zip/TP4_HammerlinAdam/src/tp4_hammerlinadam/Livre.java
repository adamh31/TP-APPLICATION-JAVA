package tp4_hammerlinadam;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author a.hammerlin
 */
public class Livre extends Media {

    private String auteur;

    public Livre(String titre, int annee, String auteur) {
        super(titre, annee);
        this.auteur = auteur;
    }

    public void lecture() {
        System.out.println("On lit " + this.getTitre());
    }

    public String getInfo() {
        return ("Auteur : " + this.auteur);
    }
}
