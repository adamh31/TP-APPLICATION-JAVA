/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp4_hammerlinadam;

/**
 *
 * @author a.hammerlin
 */
public class TP4_HammerlinAdam {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MediaCenter mediaCenter = new MediaCenter();
        mediaCenter.addMedia(new Image("L'homme de Vitruve", 1490, "Léonard de Vinci"));
        mediaCenter.addMedia(new Livre("Ravages", 1943, "René Barjavel"));
        mediaCenter.addMedia(new Video("Wrong Cops", 2013, "Quentin Dupieux"));
        mediaCenter.addMedia(new Son("Seven laws of Woo", 1992, "Praxis", null, "Praxis"));
        mediaCenter.addMedia(new Livre("Les fleurs du mal", 1857, "Charles Baudelaire"));
        mediaCenter.addMedia(new Video("Fight club", 1999, "David Fincher"));
        mediaCenter.addMedia(new Image("Trahison des images", 1929, "René Magritte"));
        mediaCenter.addMedia(new Son("Frizzle fry", 1990, "Primus/Todd Huth", "Les Claypool", "Primus"));
        mediaCenter.addMedia(new Video("Snatch", 2000, "Guy Ritchie"));
        mediaCenter.addMedia(new Livre("Pourquoi j'ai mangé mon père", 1960, "Roy Lewis"));
        mediaCenter.addMedia(new Son("Kebos", 2019, "Umano", "Zalbecino/LeRose", "Zalbecino feat. LeRose"));
        mediaCenter.addMedia(new Video("Black mirror", 2011, "Charlie Brooker"));
        System.out.println("Affichage des médias :");
        System.out.println(mediaCenter);
        System.out.println("Lecture des médias :");
        mediaCenter.lecture();

    }

}
