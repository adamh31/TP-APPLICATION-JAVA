/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp4_hammerlinadam;

/**
 *
 * @author a.hammerlin
 */
public class Video extends Media {

    private String realisateur;

    public Video(String titre, int annee, String realisateur) {
        super(titre, annee);
        this.realisateur = realisateur;
    }

    public void lecture() {
        System.out.println("On regarde le film " + this.getTitre());
    }

    public String getInfo() {
        return ("realisateur : " + this.realisateur);
    }
}
