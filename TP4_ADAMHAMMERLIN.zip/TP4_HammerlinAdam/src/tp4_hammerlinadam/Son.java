/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp4_hammerlinadam;

/**
 *
 * @author a.hammerlin
 */
public class Son extends Media {

    private String compositeur;
    private String auteur;
    private String interprete;

    public Son(String titre, int annee, String compositeur, String auteur, String interprete) {
        super(titre, annee);
        this.compositeur = compositeur;
        this.auteur = auteur;
        this.interprete = interprete;
    }

    public void lecture() {
        System.out.println("On ecoute " + this.getTitre());
    }

    public String getInfo() {
        return ("Compositeur : " + this.compositeur + ", auteur : " + this.auteur + ", interprete : " + this.interprete);
    }
}
