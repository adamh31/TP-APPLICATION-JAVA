/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp4_hammerlinadam;

import java.util.ArrayList;

/**
 *
 * @author a.hammerlin
 */
public class MediaCenter {

    private ArrayList<Media> medias;

    public MediaCenter() {
      this.medias=new ArrayList<>();
    }

    public void addMedia(Media medias) {
        this.medias.add(medias);
    }

    public void lecture() {
        for (Media elem : this.medias) {
            elem.lecture();
        }
         }
      public String toString(){
          String info = "";
        for (Media elem : this.medias) {
            info = info + elem.toString() + "\n";
            }
        return info;
    }
}


