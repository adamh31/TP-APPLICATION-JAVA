﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP1Ex5
{
    class Program
    {
        static void Main(string[] args)
        {
            int annee = 2021;
            int age=18;
            Console.WriteLine("en " + annee + " tu as " + age + " ans !");

            annee = annee + 29;
            age = age + 29;
            Console.WriteLine("en " + annee + " tu as " + age + " ans !");
            Console.ReadKey();

        }
    }
}
