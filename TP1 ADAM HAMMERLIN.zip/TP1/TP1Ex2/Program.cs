﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP1Ex2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declaration variable nom 
            string nom;

            //Declaration variable age
            int age;

            // Declaration variable taille
            double taille;

            // Declaration variable covid
            bool covid;

            nom = ("superman");
            age = 31;
            taille = 1.80;
            covid = false;

            Console.WriteLine(nom);
            Console.WriteLine(age);
            Console.WriteLine(taille);
            Console.WriteLine(covid);
            Console.ReadKey();
        }
    }
}
