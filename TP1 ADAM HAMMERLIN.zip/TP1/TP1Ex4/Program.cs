﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP1Ex4
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 2;
            int y = 3;

            y = 10;
            Console.Write("inverse de x :");
            Console.WriteLine(-x);

            Console.Write("inverse de y :");
            Console.WriteLine(-y);
            
            Console.Write("addition :");
            Console.WriteLine(x+"+"+y+"="+ (x+y));
            
            Console.Write("multiplication :");
            Console.WriteLine(x +"*"+y+"=" + (x*y));


            Console.Write("soustraction :");
            Console.WriteLine(x + "-" + y + "=" + (x - y));

            Console.Write("division :");
            Console.WriteLine(x + "/" + y + "=" + (x / y));
            
            Console.Write("modulo :");
            Console.WriteLine(x + "%" + y + "=" + (x % y));

            Console.ReadKey();




        }
    }
}
