﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP1Ex3
{
    class Program
    {
        static void Main(string[] args)
        {
            string ville ="SaintEtienne";
            Console.WriteLine (ville);
            

            ville = "Pointe A Pitre";

            Console.WriteLine(ville);
          

            ville = "Canals";

            Console.WriteLine(ville);
            Console.ReadKey();

        }
    }
}
