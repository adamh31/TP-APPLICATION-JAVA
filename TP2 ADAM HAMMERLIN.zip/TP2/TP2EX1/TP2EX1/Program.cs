﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP2EX1
{
    class Program
    {
        static void Main(string[] args)
        {
            string surnom;
            string prenom;
            string nom;

            Console.WriteLine("Veuillez saisir votre surnom");
            surnom = Console.ReadLine();
            Console.WriteLine("Veuillez saisir votre prenom");
            prenom = Console.ReadLine();
            Console.WriteLine("Veuillez saisir votre nom");
            nom = Console.ReadLine();
            Console.WriteLine("Je te salue " +  prenom +" "+ nom  +  " aka "  +  surnom);

            Console.ReadKey();



        }

    }

}