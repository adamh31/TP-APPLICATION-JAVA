﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP2EX4
{
    class Program
    {
        static void Main(string[] args)
        {

            int datenaissance;
            
            Console.WriteLine("Saisir votre date de naissance");
            datenaissance = int.Parse(Console.ReadLine());
            Console.WriteLine("Vous avez " + (2021-datenaissance) +"ans" );
            Console.ReadKey();



        }
    }
}
