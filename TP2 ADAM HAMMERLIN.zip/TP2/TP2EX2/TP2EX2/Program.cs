﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP2EX2
{
    class Program
    {
        static void Main(string[] args)
        {
            string syllabe1;
            string syllabe2;

            Console.WriteLine("Pense a un mot de 2 syllabes...");
            Console.WriteLine("Saisissez la premiere syllabe");
            syllabe1 = Console.ReadLine();
            Console.WriteLine("Saisissez la deuxieme syllabe");
            syllabe2 = Console.ReadLine();
            Console.WriteLine("Tu as pensé au mot " + syllabe1 + syllabe2);
            Console.WriteLine("En verlan , ca donne " + syllabe2  +syllabe1);
            
            Console.ReadKey();
            
              

        }
    }
}
