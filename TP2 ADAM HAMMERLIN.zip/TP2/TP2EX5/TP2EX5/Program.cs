﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP2EX5
{
    class Program
    {
        static void Main(string[] args)
        {
            float a;
            float b;
            float c;
            float moyenne;
            Console.WriteLine("Saisissez 3 notes");
             a = float.Parse(Console.ReadLine());
             b = float.Parse(Console.ReadLine());
            c = float.Parse(Console.ReadLine());
            moyenne = ((a + b + c) / 3);
            Console.WriteLine("Votre moyenne est de " + moyenne);
            Console.ReadKey();
           

        }
    }
}
