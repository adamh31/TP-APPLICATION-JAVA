/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp3ex1adamhammerlin;

public class Item {

    protected String nom;
    protected int poids;

    public Item(String nom, int poids) {
        this.nom = nom;
        this.poids = poids;
    }

    public String getNom() {
        return this.nom;
    }

    public int getPoids() {
        return this.poids;
    }

    public String toString() {
        return nom + " poids : " + poids + " kg";
    }
}
