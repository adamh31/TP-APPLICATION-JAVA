/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp3ex1adamhammerlin;

/**
 *
 * @author a.hammerlin
 */
public class Armure extends Item {

    protected int defense;

    public Armure(String nom, int poids, int defense) {
        super(nom, poids);
        this.defense = defense;
    }

    public int getDefense() {
        return this.defense;
    }

    public String toString() {
        return super.toString() + " / defense : " + defense + " Points de defense";
    }
}
