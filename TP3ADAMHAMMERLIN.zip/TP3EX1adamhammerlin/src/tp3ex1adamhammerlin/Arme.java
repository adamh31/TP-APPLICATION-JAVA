/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp3ex1adamhammerlin;



public class Arme extends Item {

    protected int degat;

    public Arme(String nom, int poids, int degat) {
        super(nom, poids);
        this.degat = degat;
    }

    public int getdegat() {
        return this.degat;
    }

    public String toString() {
        return super.toString() + " / degats : " + degat + " PV";
    }
}
