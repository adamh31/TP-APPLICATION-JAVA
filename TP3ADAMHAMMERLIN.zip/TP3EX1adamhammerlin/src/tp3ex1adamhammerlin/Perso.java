/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp3ex1adamhammerlin;


public class Perso {

    private String nom;
    private int vie;
    private int force;
    private Arme arme;
    private Armure armure;


    public Perso() {
        this("noname");
    }
    
    public Perso(String nom) {
        this(nom, 100, 30);
    }
    
    public Perso(String nom, int vie, int force) {
        this.nom = nom;
        this.vie = vie;
        this.force = force;
    }
    
    public void setArme( Arme arme ) {
        this.arme = arme;
       
    }
    
    public void setArmure(Armure armure) {
        this.armure = armure;
        
    }
    
    public void removeArme(Armure armure) {
        this.arme = null;
        
    }
    
    public void removeArmure(Armure armure) {
        this.armure = null;
        
    }
    
    public void attaque(Perso defenseur) { // this attaque defenseur !
        int ptsAttaqueThis, ptsDefenseDefenseur;
        
        ptsAttaqueThis = this.getPointsAttaque();
        ptsDefenseDefenseur = defenseur.getPointsDefense();
        
        if (ptsAttaqueThis > ptsDefenseDefenseur) {
            defenseur.degats(ptsAttaqueThis - ptsDefenseDefenseur);
        }
    }
    
    public int getPointsAttaque() { // retourne les points d'attaque d'un personnage (force+armeAttaque)
        return this.force +  this.arme.getdegat();
    }
    
    public int getPointsDefense() { // retourne les points de défense d'un personnage (armureDefense)
        return this.armure.getDefense();
    }
    
    public void degats(int nbDegats) { // prend un nombre de points de dégâts en paramètre et l'enlèvera à la vie du personnage    
        this.vie = this.vie - nbDegats;
    }
    
    @Override
    public String toString() {
        return String.format("%s - Vie:%d - Force:%d+%d(%s) - Defense : %d(%s)",
                this.nom,
                this.vie,
                this.force,
                this.arme.getdegat(),
                this.arme,
                this.arme.getdegat(),
                this.armure);
        
    }
    
}


