/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp3ex1adamhammerlin;

/**
 *
 * @author a.hammerlin
 */
public class TP3EX1adamhammerlin {

    public static void main(String[] args) {
        Item bleuvage = new Item("bleuvage", 24);
        Armure cote = new Armure("Cote", 65, 87);
        Arme LancePoule = new Arme("Lance-Poule", 17, 64);
        Perso adam = new Perso ("Adam",1,1);
        adam.setArme(LancePoule);
        adam.setArmure(cote);

        bleuvage.getNom();
        System.out.println(bleuvage.getNom());
        bleuvage.getPoids();
        System.out.println(bleuvage.getPoids());
        bleuvage.toString();
        System.out.println(bleuvage);
        System.out.println(cote);
        System.out.println(LancePoule);
        System.out.println(adam);

    }

}
