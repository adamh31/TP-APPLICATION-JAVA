/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp3ex2adamhammerlin;

/**
 *
 * @author a.hammerlin
 */
public class CompteENT {

    private String login;
    private String pass;

    public CompteENT(String login, String pass) {
        this.login = login;
        this.pass = pass;
    }

    public String getLogin(String login) {
        return this.login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPass(String pass) {
        return this.pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public String toString() {
        return this.login + this.pass;
    }
}
