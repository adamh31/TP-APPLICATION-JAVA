/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp3ex2adamhammerlin;

/**
 *
 * @author a.hammerlin
 */
public class TP3EX2ADAMHAMMERLIN {

    public static void main(String[] args) {
        Eleve rayan = new Eleve("Rayan", " Akmouch" );
        Eleve vincent = new Eleve("Vincent", " Urbanski");
        Eleve nolhan = new Eleve("Nolhan", " Charlet");
        Eleve remi = new Eleve("Remi", " Pontello");
        CompteENT compterayan = new CompteENT("LOgin " , "cocasse");
        System.out.println(rayan);
        System.out.println(vincent);
        System.out.println(nolhan);
        System.out.println(remi);
        rayan.setCompte(compterayan);
        System.out.println(rayan);

    }

}
