/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp3ex2adamhammerlin;

/**
 *
 * @author a.hammerlin
 */
public class Eleve {
    private String nom;
    private String prenom;
    private CompteENT compteENT;
    
    public Eleve(String nom , String prenom) {
        this.nom=nom;
        this.prenom=prenom;
    }
    public String getNom(String nom) {
        return this.nom;
    }
    public void setNom(String nom){
        this.nom=nom;
    }
    public String getPrenom(String prenom){
    return this.prenom;
    }
    public void setPrenom(String nom){
        this.prenom=prenom;
    }
    public void setCompte(CompteENT compte){
        this.compteENT=compte;
    }
    public String toString() {
        return this.nom +  this.prenom + " " +  this.compteENT ;
        
    }
      
}
      

