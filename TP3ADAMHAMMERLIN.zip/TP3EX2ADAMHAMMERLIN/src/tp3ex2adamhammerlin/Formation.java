/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp3ex2adamhammerlin;

import java.util.ArrayList;

/**
 *
 * @author a.hammerlin
 */
public class Formation {

    private String intitule;
    private ArrayList<Eleve> eleves;
    private Eleve eleve;

    public Formation(String formation) {

    }

    public String getIntitule(String intitule) {
        return this.intitule;
    }

    public void setIntitule(String intiutle) {
        this.intitule = intitule;
    }

    public void addEleve(Eleve eleve) {
        this.eleve.add(eleves);
    }

    public void removeEleve(Eleve eleve) {
        this.eleve.remove(eleves);
    }
}
