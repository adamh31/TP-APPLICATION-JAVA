/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp1ex1etapes1et2;

/**
 *
 * @author Philippe
 */
public class TP1Ex1Etapes1Et2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Etape 1
        Perso heros = new Perso();
        Perso mechant = new Perso();
        
        System.out.println(heros.toString());
        System.out.println(mechant.toString());
        
        
        // Etape 2.5
        Perso p1 = new Perso("Didier");
        Perso p2 = new Perso("Robert", 90, 50);
        Perso p3 = new Perso();
        
        System.out.println(p1.toString());
        System.out.println(p2.toString());
        System.out.println(p3.toString());
    }
    
}
